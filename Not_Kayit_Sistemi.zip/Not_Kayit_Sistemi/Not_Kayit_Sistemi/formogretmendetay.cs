﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Not_Kayit_Sistemi
{
    public partial class formogretmendetay : Form
    {
        public formogretmendetay()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Server=DESKTOP-TTT8CS4\SQLEXPRESS;Database=DbNotKayit;Integrated Security=True;");
        
        private void formogretmendetay_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.TBLders' table. You can move, or remove it, as needed.
            this.tBLdersTableAdapter.Fill(this.dataSet1.TBLders);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti .Open ();     
            SqlCommand komut = new SqlCommand("insert into TBLders (ogrnumara,ograd,ogrsoyadi) values (@p1, @p2, @p3) ", baglanti);
            komut.Parameters.AddWithValue("@p1", mskNumara.Text);
            komut.Parameters.AddWithValue("@p2", tbxAd .Text);
            komut.Parameters.AddWithValue("@p3", tbxSoyad .Text);
            komut.ExecuteNonQuery ();               
            baglanti .Close ();
            MessageBox.Show("öğrenci sisteme eklendi");
            this.tBLdersTableAdapter.Fill(this.dataSet1.TBLders);    





        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)   
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;

            mskNumara.Text = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            tbxAd .Text = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            tbxSoyad .Text = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            tbxSinav1 .Text =dataGridView1 .Rows[secilen].Cells[4].Value.ToString();  
            tbxSinav2.Text = dataGridView1.Rows[secilen].Cells[5].Value.ToString();     
            tbxSinav3.Text = dataGridView1.Rows[secilen].Cells[6].Value.ToString();     
                                                                                        

            
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            double ortalama, s1, s2, s3;
            string durum;
            s1 = Convert.ToDouble(tbxSinav1.Text);
            s2 = Convert.ToDouble(tbxSinav2.Text);
            s3 = Convert.ToDouble(tbxSinav3.Text);
            ortalama = (s1 + s2 + s3) / 3;
            lblSinifort.Text = ortalama.ToString("F2");  

            durum = (ortalama >= 50) ? "True" : "False";
           
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("UPDATE TBLders SET ogrs1=@p1, ogrs2=@p2, ogrs3=@p3, ortalama=@p4, durum=@p5 WHERE ogrnumara=@p6", baglanti);
                komut.Parameters.AddWithValue("@p1", s1);
                komut.Parameters.AddWithValue("@p2", s2);
                komut.Parameters.AddWithValue("@p3", s3);
                komut.Parameters.AddWithValue("@p4", ortalama);
                komut.Parameters.AddWithValue("@p5", durum);
                komut.Parameters.AddWithValue("@p6", mskNumara.Text);
                komut.ExecuteNonQuery();
                MessageBox.Show("Öğrenci notları güncellendi");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }

           
            this.tBLdersTableAdapter.Fill(this.dataSet1.TBLders);
        }

    }
}
